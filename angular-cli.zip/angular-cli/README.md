
ag-Grid-ng2-examples - angular-cli
==================================

Example of using ag-Grid with Angular2 and TypeScript

Building
========

Install Dependencies:

- `npm install`

Dev Server
=========

To build & run:

- `ng serve`

Navigate to `http://localhost:4200/`. The app will automatically reload if you change any of the source files.

Building
========

To build:

- `ng build`

To do a prod build:

- `ng build --prod`

The build artifacts will be stored in the `dist/` directory.
